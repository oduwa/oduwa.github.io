//
//  VPRubberLayout.h
//  VPRubberTable
//
//  Created by Vitalii Popruzhenko on 5/27/14.
//  Copyright (c) 2014 Vitaliy Popruzhenko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VPRubberSettings.h"

@interface VPRubberLayout : UICollectionViewFlowLayout{
}

@property (nonatomic, strong) UIDynamicAnimator *dynamicAnimator;

@end
