These files are from the 0.6.2 release of the huggingface pytorch port of BERT: https://github.com/huggingface/pytorch-transformers/tree/v0.6.2
